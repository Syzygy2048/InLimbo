#include "Texture.hpp"
#include <FreeImage\FreeImage.h>

#include <iostream>

using namespace projectname;


//TO-DO!!